package com.g4.dao.plug;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.g4.beans.Flight;
import com.g4.dao.FlightDao;
import com.g4.utils.Criteria;

public class FlightPlug  implements FlightDao{

	public Flight getFlight(String id) {
		// TODO Auto-generated method stub
		return new Flight("tetet�eqf");
		//return null;
	}

	public String putFlight(Flight flight, String id) {
		// TODO Auto-generated method stub
		//return "success";
		return "success";
		//return "failbro";
	}


	public List<Flight> getAllFlight() {
		// TODO Auto-generated method stub
		return new ArrayList<Flight> ((Arrays.asList(new Flight("tetet�eqf"),new Flight("az"))));
		//return null;
	}

	public String deleteFlight(String id) {
		// TODO Auto-generated method stub
		return "success";
		//return "failbro";
	}

	public void modifyFlight(String id, Flight flight) {
		// TODO Auto-generated method stub
		
	}

	public List<Flight> getByCriteria(Criteria criteria, String value) {
		// TODO Auto-generated method stub
		return null;
	}

}
