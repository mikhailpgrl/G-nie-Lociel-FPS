package com.g4.dao.plug;

import com.g4.dao.AirportDao;

public class AirportPlug implements AirportDao{

}
