package com.g4.dao;

public interface AirportDao {
	
}
